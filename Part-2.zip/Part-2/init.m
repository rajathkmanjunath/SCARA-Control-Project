clear all
close all
clc

load('kinematic_traj.mat');
